import pandas as pd
from flask import Flask, request, jsonify
from main import recommend_by_genre, recommend_popular_movies

app = Flask(__name__)

@app.route('/recommendations', methods=['POST'])
def recommendations():
    data = request.get_json()
    command = data.get('command')
    user_id = data.get('user_id')
    genre = data.get('genre')
    n = data.get('n')

    if command == "recommend_by_genre":
        recommendations = recommend_by_genre(user_id, genre, n)
        return jsonify(recommendations.to_dict(orient='records'))

    elif command == "recommend_popular_movies":
        recommendations = recommend_popular_movies(user_id)
        return jsonify(recommendations.to_dict(orient='records'))

    else:
        return jsonify({"error": "Invalid command"}), 400

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5001)
