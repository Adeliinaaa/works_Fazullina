import streamlit as st
import pandas as pd

ratings = pd.read_csv("C:/Users/Adeli/Downloads/2/ratings.csv")
movies = pd.read_csv("C:/Users/Adeli/Downloads/2/movies.csv")

# Создаем функцию для расчета взвешенного рейтинга
def weighted_rating(df, userId):
    # Фильтруем рейтинги, которые уже поставил пользователь
    user_ratings = df[df['userId'] == userId]
    watched_movies = user_ratings['movieId'].unique()

    unwatched_movies = df[~df['movieId'].isin(watched_movies)]['movieId'].unique()

    weighted_ratings = pd.DataFrame(columns=['movieId', 'weighted_rating', 'rating_count'])

    for i, movieId in enumerate(unwatched_movies):
        movie_ratings = df[df['movieId'] == movieId]
        average_rating = movie_ratings['rating'].mean()
        rating_count = len(movie_ratings)
        weighted_rating_value = average_rating * rating_count / (rating_count + 10)

        # Добавляем фильм в DataFrame с взвешенным рейтингом
        weighted_ratings.loc[i] = [movieId, weighted_rating_value, rating_count]

    weighted_ratings = weighted_ratings.sort_values('weighted_rating', ascending=False)

    weighted_ratings = weighted_ratings.merge(movies[['movieId', 'title']], on='movieId', how='left')

    return weighted_ratings

# Функция для рекомендаций по жанру
def recommend_by_genre(user_id, genre, n=10):
    genre_movies = movies[movies['genres'].str.contains(genre)]

    user_ratings = ratings[ratings['userId'] == user_id]
    watched_movies = user_ratings['movieId'].unique()
    unwatched_genre_movies = genre_movies[~genre_movies['movieId'].isin(watched_movies)]['movieId']

    # Выбираем топ-n фильмов по взвешенному рейтингу
    recommendations = weighted_rating(ratings, user_id)

    recommendations = recommendations[recommendations['movieId'].isin(unwatched_genre_movies)].head(n)

    return recommendations

# Функция для рекомендаций самых популярных фильмов
def recommend_popular_movies(user_id):
    user_ratings = ratings[ratings['userId'] == user_id]
    watched_movies = user_ratings['movieId'].unique()

    popular_movies = ratings['movieId'].value_counts().nlargest(10)
    recommendations = popular_movies[~popular_movies.index.isin(watched_movies)].head(10)

    recommendations = recommendations.to_frame(name='count')
    recommendations = recommendations.merge(movies[['movieId', 'title']], on='movieId', how='left')

    return recommendations

# Функция для получения списка жанров
def get_genres(user_id):
    user_ratings = ratings[ratings['userId'] == user_id]
    user_genres = []
    for movie_id in user_ratings['movieId']:
        movie_genres = movies[movies['movieId'] == movie_id]['genres'].iloc[0].split('|')
        for genre in movie_genres:
            if genre not in user_genres:
                user_genres.append(genre)
    return user_genres

# Создание Streamlit-приложения
st.title("Рекомендательная система фильмов")

# Справка по командам
st.sidebar.header("Справка")
st.sidebar.write("**Доступные команды:**")
st.sidebar.write("- **recommend_by_genre:** Рекомендует фильмы по жанру.")
st.sidebar.write("  - **user_id:** ID пользователя.")
st.sidebar.write("  - **genre:** Жанр фильма (например, Comedy, Drama, Action).")
st.sidebar.write("  - **n:** Количество рекомендаций.")
st.sidebar.write("- **recommend_popular_movies:** Рекомендует самые популярные фильмы.")
st.sidebar.write("- **show_genres:** Выводит список жанров, которые смотрел пользователь.")

# Получение ввода от пользователя
user_id = st.sidebar.number_input("Введите ID пользователя:", min_value=1, step=1)
command = st.sidebar.selectbox("Выберите команду", ["recommend_by_genre", "recommend_popular_movies", "show_genres"])

# Выполнение команды
if command == "recommend_by_genre":
    genre = st.sidebar.text_input("Введите жанр:", "Comedy")
    n = st.sidebar.number_input("Количество рекомендаций:", min_value=1, step=1)
    recommendations = recommend_by_genre(user_id, genre, n)
    st.write("Рекомендации по жанру {} для пользователя {}:\n".format(genre, user_id))
    st.write(recommendations[['title', 'weighted_rating']])

elif command == "recommend_popular_movies":
    recommendations = recommend_popular_movies(user_id)
    st.write("Рекомендации самых популярных фильмов для пользователя {}:\n".format(user_id))
    st.write(recommendations[['title', 'count']])

elif command == "show_genres":
    user_genres = get_genres(user_id)
    st.write("Список популярных жанров пользователя {}:\n".format(user_id))
    st.write(user_genres)