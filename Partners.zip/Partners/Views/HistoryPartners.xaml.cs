﻿using Microsoft.EntityFrameworkCore;
using Partners.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Partners.Views
{
    /// <summary>
    /// Interaction logic for HistoryPartners.xaml
    /// </summary>
    public partial class HistoryPartners : Page
    {
        public HistoryPartners(Partner partner)
        {
            InitializeComponent();

            HistoryDataGrid.ItemsSource = new DbPartnersContext().PartnerProducts
                .Include(p => p.ArticulProductNavigation)
                .Where(p => p.IdPartner == partner.IdPartner)
                .ToList();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Frame.Content = new ViewPartners();
        }
    }
}
