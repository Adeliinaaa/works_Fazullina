﻿using Microsoft.VisualBasic;
using Partners.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Partners.Views
{
    /// <summary>
    /// Interaction logic for PartnerUserControl.xaml
    /// </summary>
    public partial class PartnerUserControl : UserControl
    {
        private Partner partner;
        public PartnerUserControl(Partner partner)
        {
            InitializeComponent();
            this.partner = partner;
            Name_Partner.Content = partner.NamePartner.ToString();
            Type_Partner.Content = partner.TypePartner.ToString();
            Fio_director.Content = partner.DirectorName.ToString() + " " + 
                partner.DirectorSurname.ToString() + " " + 
                partner.DirectorPatronamic.ToString();
            Phone_director.Content = partner.PhonePartner.ToString();
            Rating.Content = partner.RatingPartner.ToString();
            DbPartnersContext dbPartnersContext = new DbPartnersContext();
            double totalSales = 0;
            foreach (PartnerProduct partnerProduct in dbPartnersContext.PartnerProducts.Where(p => p.IdPartner == partner.IdPartner))
            {
                totalSales += partnerProduct.CountProduct;
            }
            Discount.Content = CalculateDiscount(totalSales) + "%";
        }

        public double CalculateDiscount(double totalSales)
        {
            return totalSales switch
            {
                <= 10000 => 0,       
                > 10000 and <= 50000 => 5,  
                > 50000 and <= 300000 => 10, 
                > 300000 => 15,      
                _ => 0               
            };
        }

        private void Grid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            MainWindow.Frame.Content = new ManipulationPartners(partner);
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var result = MessageBox.Show("Выберите действие:\nДа: Редактирование\nНет: История",
                                         "Выберите действие",
                                         MessageBoxButton.YesNo,
                                         MessageBoxImage.Question);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    // Переход к странице Редактирования
                    MainWindow.Frame.Content = new ManipulationPartners(partner);
                    break;

                case MessageBoxResult.No:
                    // Переход к странице Истории
                    MainWindow.Frame.Content = new HistoryPartners(partner);
                    break;
            }
        }
    }
}
