﻿using Partners.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Partners.Views
{
    /// <summary>
    /// Interaction logic for ManipulationPartners.xaml
    /// </summary>
    public partial class ManipulationPartners : Page
    {
        private int _idPartner;
        private bool _isEdit = false;
        private DbPartnersContext _dbPartnersContext = new DbPartnersContext();
        public ManipulationPartners()
        {
            InitializeComponent();
            DbPartnersContext dbPartnersContext = new DbPartnersContext();
            _idPartner = (dbPartnersContext.Partners.Max(partner => partner.IdPartner) + 1);

            TypePartnerComboBox.ItemsSource = dbPartnersContext.Partners.
                Select(partner => partner.TypePartner).Distinct().ToList();

        }
        public ManipulationPartners(Partner partner)
        {
            InitializeComponent();
            _isEdit = true;
            _idPartner = partner.IdPartner;

            DbPartnersContext dbPartnersContext = new DbPartnersContext();
            TypePartnerComboBox.ItemsSource = dbPartnersContext.Partners.
                Select(partner => partner.TypePartner).Distinct().ToList();
            NamePartnerTextBox.Text = partner.NamePartner.ToString();
            SurnameDirectorTextBox.Text = partner.DirectorSurname.ToString();
            NameDirectorTextBox.Text = partner.DirectorName.ToString();
            PatronomycDirectorTextBox.Text = partner.DirectorPatronamic.ToString();
            EmailPartnerTextBox.Text = partner.EmailPartner.ToString();
            PhonePartnerTextBox.Text = partner.PhonePartner.ToString();
            IndexAddressTextBox.Text = partner.AdresIndex.ToString();
            RegionAddressTextBox.Text = partner.AdresRegion.ToString();
            CityAddressTextBox.Text = partner.AdresCity.ToString();
            StreetAddressTextBox.Text = partner.AdresStret.ToString();
            HouseAddressTextBox.Text = partner.AdresHouse.ToString();
            InnPartnerTextBox.Text = partner.InnPartner.ToString();
            RatingPartnerTextBox.Text = partner.RatingPartner.ToString();
            TypePartnerComboBox.SelectedItem = partner.TypePartner;
        }

        private void CreatePartner()
        {
            DbPartnersContext dbPartnersContext = new DbPartnersContext();
            Partner partner = new Partner(
                _idPartner,
                TypePartnerComboBox.SelectedItem.ToString(),
                NamePartnerTextBox.Text,
                SurnameDirectorTextBox.Text,
                NameDirectorTextBox.Text,
                PatronomycDirectorTextBox.Text,
                EmailPartnerTextBox.Text,
                PhonePartnerTextBox.Text,
                IndexAddressTextBox.Text,
                RegionAddressTextBox.Text,
                CityAddressTextBox.Text,
                StreetAddressTextBox.Text,
                HouseAddressTextBox.Text,
                InnPartnerTextBox.Text,
                Convert.ToInt32(RatingPartnerTextBox.Text)
                );
            dbPartnersContext.Partners.Add( partner );
            dbPartnersContext.SaveChanges();
        }

        private void EditPartner()
        {
            DbPartnersContext dbPartnersContext = new DbPartnersContext();

            var partner = dbPartnersContext.Partners.FirstOrDefault(p => p.IdPartner == _idPartner);

            try
            {
                partner.TypePartner = TypePartnerComboBox.SelectedItem.ToString();
                partner.NamePartner = NamePartnerTextBox.Text;
                partner.DirectorSurname = SurnameDirectorTextBox.Text;
                partner.DirectorName = NameDirectorTextBox.Text;
                partner.DirectorPatronamic = PatronomycDirectorTextBox.Text;
                partner.EmailPartner = EmailPartnerTextBox.Text;
                partner.PhonePartner = PhonePartnerTextBox.Text;
                partner.AdresIndex = IndexAddressTextBox.Text;
                partner.AdresRegion = RegionAddressTextBox.Text;
                partner.AdresCity = CityAddressTextBox.Text;
                partner.AdresStret = StreetAddressTextBox.Text;
                partner.AdresHouse = HouseAddressTextBox.Text;
                partner.InnPartner = InnPartnerTextBox.Text;
                partner.RatingPartner = Convert.ToInt32(RatingPartnerTextBox.Text);


                dbPartnersContext.SaveChanges();
                MessageBox.Show("Данные партнера успешно обновлены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при обновлении данных партнера: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private bool IsValid()
        {
            if (!int.TryParse(IndexAddressTextBox.Text, out int index) || index.ToString().Length != 6)
            {
                MessageBox.Show("Индекс адреса должен быть числом из 6 цифр!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!long.TryParse(InnPartnerTextBox.Text, out long inn) || inn.ToString().Length != 11)
            {
                MessageBox.Show("ИНН должен быть числом из 11 цифр!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (NamePartnerTextBox.Text.Length < 3 || NamePartnerTextBox.Text.Length > 50)
            {
                MessageBox.Show("Имя партнера должно содержать от 3 до 50 букв!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(SurnameDirectorTextBox.Text) || SurnameDirectorTextBox.Text.Length < 3 || SurnameDirectorTextBox.Text.Length > 50 || !SurnameDirectorTextBox.Text.All(char.IsLetter))
            {
                MessageBox.Show("Фамилия директора должна содержать от 3 до 50 букв и не содержать символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(NameDirectorTextBox.Text) || NameDirectorTextBox.Text.Length < 3 || NameDirectorTextBox.Text.Length > 50 || !NameDirectorTextBox.Text.All(char.IsLetter))
            {
                MessageBox.Show("Имя директора должно содержать от 3 до 50 букв и не содержать символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!string.IsNullOrWhiteSpace(PatronomycDirectorTextBox.Text) && !PatronomycDirectorTextBox.Text.All(char.IsLetter))
            {
                MessageBox.Show("Отчество директора не должно содержать символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(EmailPartnerTextBox.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Некорректный формат электронной почты!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(PhonePartnerTextBox.Text, @"^\+?\d{10,15}$"))
            {
                MessageBox.Show("Некорректный формат телефона! Допустимый формат: +71234567890 или 1234567890", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!StreetAddressTextBox.Text.StartsWith("ул. "))
            {
                MessageBox.Show("Улица должна начинаться со слов 'ул. '!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (RegionAddressTextBox.Text.Any(ch => !char.IsLetterOrDigit(ch) && !char.IsWhiteSpace(ch)))
            {
                MessageBox.Show("Регион не должен содержать специальных символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!CityAddressTextBox.Text.StartsWith("город "))
            {
                MessageBox.Show("Город должен начинаться со слов 'город '!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!HouseAddressTextBox.Text.All(char.IsLetterOrDigit) || HouseAddressTextBox.Text.Length > 3)
            {
                MessageBox.Show("Номер дома должен быть не длиннее 3 символов и содержать только буквы и цифры!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!RatingPartnerTextBox.Text.All(char.IsDigit) || RatingPartnerTextBox.Text.Length > 3)
            {
                MessageBox.Show("Рейтинг партнера должен быть числом не длиннее 3 символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (TypePartnerComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Необходимо выбрать тип партнера!",
                    "Ошибка", MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return false;
            }

            var existingPartner = _dbPartnersContext.Partners.FirstOrDefault(p => p.InnPartner == InnPartnerTextBox.Text);

            if (_isEdit)
            {
                if (existingPartner != null && existingPartner.IdPartner != _idPartner)
                {
                    MessageBox.Show("ИНН уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else
            {
                if (existingPartner != null)
                {
                    MessageBox.Show("ИНН уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            existingPartner = _dbPartnersContext.Partners.FirstOrDefault(p => p.PhonePartner == PhonePartnerTextBox.Text);

            if (_isEdit)
            {
                if (existingPartner != null && existingPartner.IdPartner != _idPartner)
                {
                    MessageBox.Show("Контактный номер телефона уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else
            {
                if (existingPartner != null)
                {
                    MessageBox.Show("Контактный номер телефона уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            existingPartner = _dbPartnersContext.Partners.FirstOrDefault(p => p.NamePartner == NamePartnerTextBox.Text);

            if (_isEdit)
            {
                if (existingPartner != null && existingPartner.IdPartner != _idPartner)
                {
                    MessageBox.Show("Наименование партнера уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else
            {
                if (existingPartner != null)
                {
                    MessageBox.Show("Наименование партнера уже существует в базе данных!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            return true;
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (!IsValid()) return;
            if (_isEdit)
            {
                EditPartner();
            }
            else
            {
                CreatePartner();
            }
            MainWindow.Frame.Content = new ViewPartners();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Frame.Content = new ViewPartners();
        }
    }
}
