﻿using Partners.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Partners.Views
{
    /// <summary>
    /// Interaction logic for ViewPartners.xaml
    /// </summary>
    public partial class ViewPartners : Page
    {
        List<Partner> partners;
        List<Partner> viewPartners = new List<Partner>();
        public ViewPartners()
        {
            InitializeComponent();
            DbPartnersContext dbPartnersContext = new DbPartnersContext();
            FilterComboBox.ItemsSource = dbPartnersContext.Partners
                                                .Select(p => p.AdresCity)
                                                .Distinct()  // Чтобы не было повторяющихся городов
                                                .ToList();
            partners = dbPartnersContext.Partners.ToList();
            foreach (Partner partner in partners)
            {
                viewPartners.Add(partner);
            }
            UpdateView();
        }

        private void UpdateView()
        {
            viewPartners.Clear();
            foreach (Partner partner in partners)
            {
                if (!String.IsNullOrEmpty(SearchTextBox.Text) && !partner.NamePartner.ToLower().Contains(SearchTextBox.Text.ToLower()))
                {
                    continue;
                }
                if (FilterComboBox.SelectedItem != null && partner.AdresCity != FilterComboBox.SelectedItem.ToString())
                {
                    continue;
                }

                viewPartners.Add(partner);
            }
            if (SortComboBox.SelectedIndex == 1)
            {
                viewPartners = viewPartners.OrderByDescending(partner => partner.RatingPartner).ToList();
            }
            else
            {
                viewPartners = viewPartners.OrderBy(partner => partner.RatingPartner).ToList();
            }
            IssuedLabel.Content = viewPartners.Count();
            IssuedFromLabel.Content = partners.Count();
            MainListView.Items.Clear();
            foreach (Partner partner in viewPartners) 
            {
                MainListView.Items.Add(new PartnerUserControl(partner));
            }

        }
        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateView();
        }

        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateView();
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateView();
        }

        private void CreateProductButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Frame.Content = new ManipulationPartners();
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            FilterComboBox.SelectedIndex = -1;
            SortComboBox.SelectedIndex = -1;
            SearchTextBox.Text = string.Empty;
            UpdateView();
        }
    }
}
