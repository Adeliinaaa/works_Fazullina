﻿using System;
using System.Collections.Generic;

namespace Partners.Models;

public partial class Product
{
    public string ArticulProduct { get; set; } = null!;

    public int? IdProductType { get; set; }

    public string NameProduct { get; set; } = null!;

    public double MinPrice { get; set; }

    public virtual ProductType? IdProductTypeNavigation { get; set; }

    public virtual ICollection<PartnerProduct> PartnerProducts { get; set; } = new List<PartnerProduct>();
}
