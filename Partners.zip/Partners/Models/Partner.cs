﻿using System;
using System.Collections.Generic;

namespace Partners.Models;

public partial class Partner
{
    public Partner(int idPartner, string typePartner, string namePartner, string directorSurname, string directorName, string directorPatronamic, string emailPartner, string phonePartner, string adresIndex, string adresRegion, string adresCity, 
        string adresStret, string adresHouse, string innPartner, int ratingPartner)
    {
        IdPartner = idPartner;
        TypePartner = typePartner;
        NamePartner = namePartner;
        DirectorSurname = directorSurname;
        DirectorName = directorName;
        DirectorPatronamic = directorPatronamic;
        EmailPartner = emailPartner;
        PhonePartner = phonePartner;
        AdresIndex = adresIndex;
        AdresRegion = adresRegion;
        AdresCity = adresCity;
        AdresStret = adresStret;
        AdresHouse = adresHouse;
        InnPartner = innPartner;
        RatingPartner = ratingPartner;
    }

    public int IdPartner { get; set; }

    public string TypePartner { get; set; } = null!;

    public string NamePartner { get; set; } = null!;

    public string DirectorSurname { get; set; } = null!;

    public string DirectorName { get; set; } = null!;

    public string DirectorPatronamic { get; set; } = null!;

    public string EmailPartner { get; set; } = null!;

    public string PhonePartner { get; set; } = null!;

    public string AdresIndex { get; set; } = null!;

    public string AdresRegion { get; set; } = null!;

    public string AdresCity { get; set; } = null!;

    public string AdresStret { get; set; } = null!;

    public string AdresHouse { get; set; } = null!;

    public string InnPartner { get; set; } = null!;

    public int RatingPartner { get; set; }

    public virtual ICollection<PartnerProduct> PartnerProducts { get; set; } = new List<PartnerProduct>();
}
