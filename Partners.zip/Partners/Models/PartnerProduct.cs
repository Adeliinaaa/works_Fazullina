﻿using System;
using System.Collections.Generic;

namespace Partners.Models;

public partial class PartnerProduct
{
    public int IdPartnerProduct { get; set; }

    public string ArticulProduct { get; set; } = null!;

    public int IdPartner { get; set; }

    public int CountProduct { get; set; }

    public DateOnly DateSales { get; set; }

    public virtual Product ArticulProductNavigation { get; set; } = null!;

    public virtual Partner IdPartnerNavigation { get; set; } = null!;
}
