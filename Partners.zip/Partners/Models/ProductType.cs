﻿using System;
using System.Collections.Generic;

namespace Partners.Models;

public partial class ProductType
{
    public int IdProductType { get; set; }

    public string NameProductType { get; set; } = null!;

    public double KoefProductType { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
