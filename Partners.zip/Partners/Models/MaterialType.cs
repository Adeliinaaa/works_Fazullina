﻿using System;
using System.Collections.Generic;

namespace Partners.Models;

public partial class MaterialType
{
    public int IdMaterialType { get; set; }

    public string NameMaterialType { get; set; } = null!;

    public double DefectMaterialType { get; set; }
}
