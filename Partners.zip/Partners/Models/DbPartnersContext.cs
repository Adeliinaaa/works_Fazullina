﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace Partners.Models;

public partial class DbPartnersContext : DbContext
{
    public DbPartnersContext()
    {
    }

    public DbPartnersContext(DbContextOptions<DbPartnersContext> options)
        : base(options)
    {
    }

    public virtual DbSet<MaterialType> MaterialTypes { get; set; }

    public virtual DbSet<Partner> Partners { get; set; }

    public virtual DbSet<PartnerProduct> PartnerProducts { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductType> ProductTypes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;user=root;password=1234;database=db_partners", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.35-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<MaterialType>(entity =>
        {
            entity.HasKey(e => e.IdMaterialType).HasName("PRIMARY");

            entity.ToTable("material_type");

            entity.Property(e => e.IdMaterialType).HasColumnName("id_material_type");
            entity.Property(e => e.DefectMaterialType)
                .HasColumnType("double(5,2)")
                .HasColumnName("defect_material_type");
            entity.Property(e => e.NameMaterialType)
                .HasMaxLength(45)
                .HasColumnName("name_material_type");
        });

        modelBuilder.Entity<Partner>(entity =>
        {
            entity.HasKey(e => e.IdPartner).HasName("PRIMARY");

            entity.ToTable("partners");

            entity.Property(e => e.IdPartner).HasColumnName("id_partner");
            entity.Property(e => e.AdresCity)
                .HasMaxLength(45)
                .HasColumnName("adres_city");
            entity.Property(e => e.AdresHouse)
                .HasMaxLength(5)
                .HasColumnName("adres_house");
            entity.Property(e => e.AdresIndex)
                .HasMaxLength(100)
                .HasColumnName("adres_index");
            entity.Property(e => e.AdresRegion)
                .HasMaxLength(45)
                .HasColumnName("adres_region");
            entity.Property(e => e.AdresStret)
                .HasMaxLength(45)
                .HasColumnName("adres_stret");
            entity.Property(e => e.DirectorName)
                .HasMaxLength(45)
                .HasColumnName("director_name");
            entity.Property(e => e.DirectorPatronamic)
                .HasMaxLength(45)
                .HasColumnName("director_patronamic");
            entity.Property(e => e.DirectorSurname)
                .HasMaxLength(50)
                .HasColumnName("director_surname");
            entity.Property(e => e.EmailPartner)
                .HasMaxLength(50)
                .HasColumnName("email_partner");
            entity.Property(e => e.InnPartner)
                .HasMaxLength(11)
                .HasColumnName("inn_partner");
            entity.Property(e => e.NamePartner)
                .HasMaxLength(50)
                .HasColumnName("name_partner");
            entity.Property(e => e.PhonePartner)
                .HasMaxLength(15)
                .HasColumnName("phone_partner");
            entity.Property(e => e.RatingPartner).HasColumnName("rating_partner");
            entity.Property(e => e.TypePartner)
                .HasMaxLength(5)
                .HasColumnName("type_partner");
        });

        modelBuilder.Entity<PartnerProduct>(entity =>
        {
            entity.HasKey(e => e.IdPartnerProduct).HasName("PRIMARY");

            entity.ToTable("partner_products");

            entity.HasIndex(e => e.IdPartner, "fk_partner");

            entity.HasIndex(e => e.ArticulProduct, "fk_product");

            entity.Property(e => e.IdPartnerProduct).HasColumnName("id_partner_product");
            entity.Property(e => e.ArticulProduct)
                .HasMaxLength(7)
                .HasColumnName("articul_product");
            entity.Property(e => e.CountProduct).HasColumnName("count_product");
            entity.Property(e => e.DateSales).HasColumnName("date_sales");
            entity.Property(e => e.IdPartner).HasColumnName("id_partner");

            entity.HasOne(d => d.ArticulProductNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.ArticulProduct)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_product");

            entity.HasOne(d => d.IdPartnerNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.IdPartner)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_partner");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.ArticulProduct).HasName("PRIMARY");

            entity.ToTable("products");

            entity.HasIndex(e => e.IdProductType, "fk_product_type");

            entity.Property(e => e.ArticulProduct)
                .HasMaxLength(7)
                .HasColumnName("articul_product");
            entity.Property(e => e.IdProductType).HasColumnName("id_product_type");
            entity.Property(e => e.MinPrice)
                .HasColumnType("double(10,2)")
                .HasColumnName("min_price");
            entity.Property(e => e.NameProduct)
                .HasMaxLength(150)
                .HasColumnName("name_product");

            entity.HasOne(d => d.IdProductTypeNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.IdProductType)
                .HasConstraintName("fk_product_type");
        });

        modelBuilder.Entity<ProductType>(entity =>
        {
            entity.HasKey(e => e.IdProductType).HasName("PRIMARY");

            entity.ToTable("product_type");

            entity.Property(e => e.IdProductType).HasColumnName("id_product_type");
            entity.Property(e => e.KoefProductType)
                .HasColumnType("double(5,2)")
                .HasColumnName("koef_product_type");
            entity.Property(e => e.NameProductType)
                .HasMaxLength(45)
                .HasColumnName("name_product_type");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
